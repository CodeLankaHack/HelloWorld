<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "***"); // db user
define('DB_PASSWORD', "***"); // db password (mention your db password here)
define('DB_DATABASE', "***"); // database name
define('DB_SERVER', "***"); // db server
?>